var core_2nslot_8h =
[
    [ "NSlot", "class_n_slot.html", "class_n_slot" ],
    [ "INHERIT_OVERRIDE", "core_2nslot_8h.html#adb163dd38531c878ddfde82758bca669", null ],
    [ "INHERIT_SAME", "core_2nslot_8h.html#ac451c67f75a057c8b7914763a6a2a7ba", null ]
];
var class_n_proc =
[
    [ "NProc", "class_n_proc.html#ac7b5a0594bc87be248e5cac20ff59cd5", null ],
    [ "NProc", "class_n_proc.html#ac7b5a0594bc87be248e5cac20ff59cd5", null ],
    [ "fromXml", "class_n_proc.html#a2597f161d28be317c576ad2f8a408b7b", null ],
    [ "fromXml", "class_n_proc.html#a2597f161d28be317c576ad2f8a408b7b", null ],
    [ "name", "class_n_proc.html#ac9313bcbb7ff9baab252b27c0f0ff274", null ],
    [ "name", "class_n_proc.html#ac9313bcbb7ff9baab252b27c0f0ff274", null ],
    [ "proc", "class_n_proc.html#aeca93bcccf0e4a2320380d3f6bcde827", null ],
    [ "proc", "class_n_proc.html#aeca93bcccf0e4a2320380d3f6bcde827", null ],
    [ "setName", "class_n_proc.html#a7d7b5be0024937e7318eb65e502c7917", null ],
    [ "setName", "class_n_proc.html#a7d7b5be0024937e7318eb65e502c7917", null ],
    [ "setProc", "class_n_proc.html#a8300775062bfe4e94323fe051aa051ab", null ],
    [ "setProc", "class_n_proc.html#a8300775062bfe4e94323fe051aa051ab", null ],
    [ "toXml", "class_n_proc.html#a9e25b51a09e921b181cd566aba698e34", null ],
    [ "toXml", "class_n_proc.html#a9e25b51a09e921b181cd566aba698e34", null ]
];
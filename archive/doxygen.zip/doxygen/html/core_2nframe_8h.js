var core_2nframe_8h =
[
    [ "NFrame", "class_n_frame.html", "class_n_frame" ],
    [ "FRAME_TYPE", "core_2nframe_8h.html#aa380b02be71bbce421af299f6025b6a4", [
      [ "prototype", "core_2nframe_8h.html#aa380b02be71bbce421af299f6025b6a4a2d34880dfef748d8db0ca890c4941e0e", null ],
      [ "exemplar", "core_2nframe_8h.html#aa380b02be71bbce421af299f6025b6a4abf952a336d6ed0eb1392003a1728b210", null ],
      [ "prototype", "core_2nframe_8h.html#aa380b02be71bbce421af299f6025b6a4a2d34880dfef748d8db0ca890c4941e0e", null ],
      [ "exemplar", "core_2nframe_8h.html#aa380b02be71bbce421af299f6025b6a4abf952a336d6ed0eb1392003a1728b210", null ]
    ] ]
];
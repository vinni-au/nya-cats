var class_question_wnd =
[
    [ "QuestionWnd", "class_question_wnd.html#abfbcdd5b5ce27f027249bf6f2499d008", null ],
    [ "QuestionWnd", "class_question_wnd.html#abfbcdd5b5ce27f027249bf6f2499d008", null ],
    [ "GetAnswer", "class_question_wnd.html#a2011a6c391e399665606fc78d8b583f8", null ],
    [ "GetAnswer", "class_question_wnd.html#a2011a6c391e399665606fc78d8b583f8", null ],
    [ "SetQuestion", "class_question_wnd.html#a9066b2e1643006b9afb66d7ae3f9c430", null ],
    [ "SetQuestion", "class_question_wnd.html#a9066b2e1643006b9afb66d7ae3f9c430", null ],
    [ "btnCancel", "class_question_wnd.html#a3b18e8787761391c0343aebe0dfd610a", null ],
    [ "btnOk", "class_question_wnd.html#af2427c2e2df81285611421fab3ec6e06", null ],
    [ "cmbVariants", "class_question_wnd.html#a715d6d03f1e20382fdd10f9e08ddd351", null ],
    [ "layButtons", "class_question_wnd.html#aa4cd27c74ccff8dd7a8f16ecff3ba96d", null ],
    [ "layMain", "class_question_wnd.html#aa0f132ed984d85508e270fddc04988d6", null ],
    [ "layVariants", "class_question_wnd.html#a5d23df049e51c8984f893d2310e78d9c", null ],
    [ "lbQuestion", "class_question_wnd.html#aaf8d1b148cafdee2fc2bbac4ac41dd98", null ],
    [ "lbVar", "class_question_wnd.html#a7f48669e622c71eeee18a2af2034645c", null ]
];
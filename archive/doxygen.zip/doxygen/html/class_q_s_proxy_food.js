var class_q_s_proxy_food =
[
    [ "QSProxyFood", "class_q_s_proxy_food.html#afac05d1a4dda718254d5060a2d0cae9e", null ],
    [ "QSProxyFood", "class_q_s_proxy_food.html#afac05d1a4dda718254d5060a2d0cae9e", null ]
];
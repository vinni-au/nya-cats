var class_ui___proc_editor =
[
    [ "retranslateUi", "class_ui___proc_editor.html#a03987d9e73500b4507eefa0a529eaa8d", null ],
    [ "retranslateUi", "class_ui___proc_editor.html#a03987d9e73500b4507eefa0a529eaa8d", null ],
    [ "setupUi", "class_ui___proc_editor.html#a020e762b6101258fd9f9f7ad1bec8fa0", null ],
    [ "setupUi", "class_ui___proc_editor.html#a020e762b6101258fd9f9f7ad1bec8fa0", null ],
    [ "buttonBox", "class_ui___proc_editor.html#a3b03cbcfda6fe4a05e787dba7e9fdfbc", null ],
    [ "plainTextEdit", "class_ui___proc_editor.html#a277daff637f50b55fd096134c6b135ea", null ],
    [ "verticalLayout", "class_ui___proc_editor.html#a450af5e5b2c50bd4a75a16614fabe547", null ],
    [ "verticalLayout_2", "class_ui___proc_editor.html#a74c58437a6bd3bacc53290436270f921", null ]
];
var class_view =
[
    [ "View", "class_view.html#a4096da0b5a8ef74aaa5d01b9e856c846", null ],
    [ "View", "class_view.html#a4096da0b5a8ef74aaa5d01b9e856c846", null ],
    [ "view", "class_view.html#aa6a96bfdfa5a88ae006fcaf04989a6d9", null ],
    [ "view", "class_view.html#a6c16a6acad42e6fb96a135795fd6ac65", null ]
];
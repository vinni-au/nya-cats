var class_n_frame_node =
[
    [ "Type", "class_n_frame_node.html#ac3b53c68976e21afcab76ad3a184781a", [
      [ "Root", "class_n_frame_node.html#ac3b53c68976e21afcab76ad3a184781aa5c3207782390b67e29c5b0d47aafde7d", null ],
      [ "FrameName", "class_n_frame_node.html#ac3b53c68976e21afcab76ad3a184781aa1082542018e8379e564cd22001ac1f53", null ],
      [ "Faset", "class_n_frame_node.html#ac3b53c68976e21afcab76ad3a184781aab0f16d45bdc67f297dc983d31eb77b44", null ],
      [ "Root", "class_n_frame_node.html#ac3b53c68976e21afcab76ad3a184781aa5c3207782390b67e29c5b0d47aafde7d", null ],
      [ "FrameName", "class_n_frame_node.html#ac3b53c68976e21afcab76ad3a184781aa1082542018e8379e564cd22001ac1f53", null ],
      [ "Faset", "class_n_frame_node.html#ac3b53c68976e21afcab76ad3a184781aab0f16d45bdc67f297dc983d31eb77b44", null ]
    ] ],
    [ "Type", "class_n_frame_node.html#ac3b53c68976e21afcab76ad3a184781a", [
      [ "Root", "class_n_frame_node.html#ac3b53c68976e21afcab76ad3a184781aa5c3207782390b67e29c5b0d47aafde7d", null ],
      [ "FrameName", "class_n_frame_node.html#ac3b53c68976e21afcab76ad3a184781aa1082542018e8379e564cd22001ac1f53", null ],
      [ "Faset", "class_n_frame_node.html#ac3b53c68976e21afcab76ad3a184781aab0f16d45bdc67f297dc983d31eb77b44", null ],
      [ "Root", "class_n_frame_node.html#ac3b53c68976e21afcab76ad3a184781aa5c3207782390b67e29c5b0d47aafde7d", null ],
      [ "FrameName", "class_n_frame_node.html#ac3b53c68976e21afcab76ad3a184781aa1082542018e8379e564cd22001ac1f53", null ],
      [ "Faset", "class_n_frame_node.html#ac3b53c68976e21afcab76ad3a184781aab0f16d45bdc67f297dc983d31eb77b44", null ]
    ] ],
    [ "NFrameNode", "class_n_frame_node.html#a0e18994980324ff3712cc8dc5b951248", null ],
    [ "~NFrameNode", "class_n_frame_node.html#a479bcf563feda3122d7323ca424eec0f", null ],
    [ "NFrameNode", "class_n_frame_node.html#a0e18994980324ff3712cc8dc5b951248", null ],
    [ "~NFrameNode", "class_n_frame_node.html#a479bcf563feda3122d7323ca424eec0f", null ],
    [ "children", "class_n_frame_node.html#ae61d42a5420d3c629ba5640edafa97e0", null ],
    [ "frame", "class_n_frame_node.html#a75bd286e2005bf1c13e38e3366a4cc01", null ],
    [ "parent", "class_n_frame_node.html#ad87210cf1ad5cadb0c585680aeb80d0e", null ],
    [ "type", "class_n_frame_node.html#a505e19a5298af41dcd622344bd3875e8", null ]
];
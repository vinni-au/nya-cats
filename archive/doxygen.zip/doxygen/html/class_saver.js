var class_saver =
[
    [ "Saver", "class_saver.html#a7f1ef50c20315010bed17eb311c631ba", null ],
    [ "Saver", "class_saver.html#a7f1ef50c20315010bed17eb311c631ba", null ],
    [ "Saver", "class_saver.html#a7f1ef50c20315010bed17eb311c631ba", null ],
    [ "Saver", "class_saver.html#a7f1ef50c20315010bed17eb311c631ba", null ]
];
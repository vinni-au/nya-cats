var class_ui___m_l_v_control =
[
    [ "retranslateUi", "class_ui___m_l_v_control.html#a46d8ecd0b966d0ee3edea6474015a41d", null ],
    [ "retranslateUi", "class_ui___m_l_v_control.html#a46d8ecd0b966d0ee3edea6474015a41d", null ],
    [ "setupUi", "class_ui___m_l_v_control.html#acb65bc2b3e1652bb515cd43c00024361", null ],
    [ "setupUi", "class_ui___m_l_v_control.html#acb65bc2b3e1652bb515cd43c00024361", null ],
    [ "horizontalLayout", "class_ui___m_l_v_control.html#a2d0e178ed02d3fb533a53a7d0d750c04", null ],
    [ "horizontalLayout_2", "class_ui___m_l_v_control.html#aaf272ae79ce0173af261108478eb148c", null ],
    [ "horizontalLayout_3", "class_ui___m_l_v_control.html#a3e803349639f64c53864ed05fe46c111", null ],
    [ "horizontalLayout_4", "class_ui___m_l_v_control.html#a4bad80f3f21553a4860b7dfdbffa048f", null ],
    [ "lineOfReasoning", "class_ui___m_l_v_control.html#ae05a45758ab18f1dfa99f14869493ad7", null ],
    [ "listLog", "class_ui___m_l_v_control.html#aeba1df4cddd05cd0765cba70099d9b73", null ],
    [ "tab", "class_ui___m_l_v_control.html#afcd2914eea7a59dfd1940c802fbe7f3b", null ],
    [ "tab_2", "class_ui___m_l_v_control.html#a7eee619ac0daa247d1ab515ed2ec4282", null ],
    [ "tab_3", "class_ui___m_l_v_control.html#a168c546548b5e16486058d7e6597851a", null ],
    [ "tabWidget", "class_ui___m_l_v_control.html#ad87e21aef3563bb59c3a58329f32f881", null ],
    [ "treeView", "class_ui___m_l_v_control.html#acea462a32a0f77a8b7349c51fd25be6f", null ]
];
var dir_be7eb357c31db37885d3b644ed3fab94 =
[
    [ "nframenetmodel.cpp", "core_2frame__model_2nframenetmodel_8cpp.html", null ],
    [ "nframenetmodel.h", "core_2frame__model_2nframenetmodel_8h.html", [
      [ "NFramenetModel", "class_n_framenet_model.html", "class_n_framenet_model" ]
    ] ],
    [ "nframenetmodelhierarchical.cpp", "core_2frame__model_2nframenetmodelhierarchical_8cpp.html", null ],
    [ "nframenetmodelhierarchical.h", "core_2frame__model_2nframenetmodelhierarchical_8h.html", [
      [ "NFramenetModelHierarchical", "class_n_framenet_model_hierarchical.html", "class_n_framenet_model_hierarchical" ]
    ] ],
    [ "nframenode.cpp", "core_2frame__model_2nframenode_8cpp.html", null ],
    [ "nframenode.h", "core_2frame__model_2nframenode_8h.html", [
      [ "NFrameNode", "class_n_frame_node.html", "class_n_frame_node" ]
    ] ]
];
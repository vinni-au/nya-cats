var class_l_gen2_object_properties_editor =
[
    [ "LGen2ObjectPropertiesEditor", "class_l_gen2_object_properties_editor.html#ad77c063d3c8186214eb41a7290ab68c7", null ],
    [ "LGen2ObjectPropertiesEditor", "class_l_gen2_object_properties_editor.html#ad77c063d3c8186214eb41a7290ab68c7", null ]
];
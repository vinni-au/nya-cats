var class_q_s_proxy_man =
[
    [ "QSProxyMan", "class_q_s_proxy_man.html#a6579dcb4ec127f4feba0290a37304116", null ],
    [ "QSProxyMan", "class_q_s_proxy_man.html#a6579dcb4ec127f4feba0290a37304116", null ],
    [ "Life", "class_q_s_proxy_man.html#afea839662dcbee025de985f804d8c983", null ],
    [ "Life", "class_q_s_proxy_man.html#afea839662dcbee025de985f804d8c983", null ],
    [ "setLife", "class_q_s_proxy_man.html#a4f510ccfe598299c081eed4ac39fc6e3", null ],
    [ "setLife", "class_q_s_proxy_man.html#a4f510ccfe598299c081eed4ac39fc6e3", null ],
    [ "Life", "class_q_s_proxy_man.html#a889b183615e7fa8964dc926710e1379a", null ]
];
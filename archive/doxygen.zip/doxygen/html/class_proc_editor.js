var class_proc_editor =
[
    [ "ProcEditor", "class_proc_editor.html#ad08973174b028bb15f8c2266302278d5", null ],
    [ "~ProcEditor", "class_proc_editor.html#a7550c740d29b13c46929eab2c24251bb", null ],
    [ "ProcEditor", "class_proc_editor.html#ad08973174b028bb15f8c2266302278d5", null ],
    [ "~ProcEditor", "class_proc_editor.html#a7550c740d29b13c46929eab2c24251bb", null ],
    [ "sigProcAdded", "class_proc_editor.html#aaf5edfe4861462691ad23f1f9f636880", null ],
    [ "sigProcAdded", "class_proc_editor.html#aaf5edfe4861462691ad23f1f9f636880", null ]
];
var class_variable =
[
    [ "Variable", "class_variable.html#aae3257f8d547b7d8ac14bf789baa162b", null ],
    [ "Variable", "class_variable.html#aae3257f8d547b7d8ac14bf789baa162b", null ],
    [ "asking", "class_variable.html#a3f0d53d3639fc183dc828cf74ed6e6dd", null ],
    [ "derivable", "class_variable.html#a0a89365d32a58cb17154e28a7503a165", null ],
    [ "domain", "class_variable.html#a74e964b965c028ef8c485ef8a0b3c08e", null ],
    [ "name", "class_variable.html#a6602fc2ef694dd77e478f0668fcaa1b5", null ],
    [ "question", "class_variable.html#a8432edfe9f00686908c58807a9503596", null ]
];
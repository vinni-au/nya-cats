var debug_2qrc__res_8cpp =
[
    [ "qCleanupResources_res", "debug_2qrc__res_8cpp.html#aaf71e5ae021cee5faf373b79b1a647cd", null ],
    [ "qInitResources_res", "debug_2qrc__res_8cpp.html#a0419f412818ee63e0b138600ca41ac22", null ],
    [ "qRegisterResourceData", "debug_2qrc__res_8cpp.html#ab3bec3d1e679084be46edc41e4c91bc1", null ],
    [ "qUnregisterResourceData", "debug_2qrc__res_8cpp.html#ad65f8bca8010dd1fd135a28a085c6d03", null ]
];
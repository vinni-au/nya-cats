var class_ui___frame_editor_wnd =
[
    [ "retranslateUi", "class_ui___frame_editor_wnd.html#a7b7bfc5deef017f6b80ab3efd3d0e18e", null ],
    [ "retranslateUi", "class_ui___frame_editor_wnd.html#a7b7bfc5deef017f6b80ab3efd3d0e18e", null ],
    [ "setupUi", "class_ui___frame_editor_wnd.html#a3dd4eac3926e790ef82803fe3338a0cd", null ],
    [ "setupUi", "class_ui___frame_editor_wnd.html#a3dd4eac3926e790ef82803fe3338a0cd", null ]
];
var class_main_window =
[
    [ "MainWindow", "class_main_window.html#a8b244be8b7b7db1b08de2a2acb9409db", null ],
    [ "~MainWindow", "class_main_window.html#ae98d00a93bc118200eeef9f9bba1dba7", null ],
    [ "MainWindow", "class_main_window.html#a8b244be8b7b7db1b08de2a2acb9409db", null ],
    [ "~MainWindow", "class_main_window.html#ae98d00a93bc118200eeef9f9bba1dba7", null ],
    [ "closeEvent", "class_main_window.html#a4e20a4a065fbb0e4d3532a45a0a91425", null ],
    [ "closeEvent", "class_main_window.html#a4e20a4a065fbb0e4d3532a45a0a91425", null ],
    [ "saveAs", "class_main_window.html#a29cf7bd0dd9c5ab61fe788a54953cc63", null ],
    [ "saveAs", "class_main_window.html#a29cf7bd0dd9c5ab61fe788a54953cc63", null ],
    [ "btnStartGame", "class_main_window.html#a3036d1bc3d1fd03741f53abb142f2606", null ],
    [ "btnStartRandomGame", "class_main_window.html#a8396bafa64688fd7333211b3263a2353", null ],
    [ "btnStep", "class_main_window.html#ade9e9660a55ea103ec825531473c28ba", null ],
    [ "btnStopGame", "class_main_window.html#a58548d7e5b3cbb9602a2617dd3717f8b", null ],
    [ "hlayout", "class_main_window.html#aa0d7c9c9cb2238c14211f04bdca599a6", null ],
    [ "viz", "class_main_window.html#aba53ac2e5258a3610e745f47b22eb8aa", null ],
    [ "vlayout", "class_main_window.html#a53fe974710bf73a9fc86bed0e5fb3895", null ]
];